function downloadFile(filePath) {
    window.location.href = filePath;
}